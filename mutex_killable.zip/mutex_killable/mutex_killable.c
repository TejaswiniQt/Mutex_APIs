#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/kthread.h> // therad 
#include <linux/delay.h>   // sleep 
#include <linux/sched.h>  
#include <linux/mutex.h> //step1
/*

	1  create a module 
	2. create a thread and execute.

*/
 
//dynamic method of implementing mutex


MODULE_LICENSE("GPL");

struct mutex my_mutex; //step2
int count =0;





int  my_thread_handle(void *p);
int  my_thread_handle1(void *p);

struct task_struct * char_thread,*char_thread1;

int my_thread_handle(void *p)
{
int lock;

	while(!kthread_should_stop())
	{
	     
		lock=mutex_lock_killable(&my_mutex);
		if(lock==0)
		{
		printk("In thread function1 count=%d\n",count++);
		}
		else
		{
		printk("interrupted by sigkill signal\n");
		}
		mutex_unlock(&my_mutex);
		msleep(1000);
	}	
	return 0;
}


int my_thread_handle1(void *p)
{
	while(!kthread_should_stop())
	{
		mutex_lock(&my_mutex);
		printk("In thread function2 count=%d\n",count++);
		mutex_unlock(&my_mutex);
		msleep(1000);
	}	
	return 0;
}

static int __init my_thread_driver_init(void)
{
	
	printk("init driver\n");
	
	//initializing the mutex
	mutex_init(&my_mutex);
	


	char_thread = kthread_run(my_thread_handle, NULL, "therad1");

	if(char_thread)
	{
		printk("thread1 created successfully");
	}
	else
	{
		printk("thread1 created failed");
		 
	}

	char_thread1 = kthread_run(my_thread_handle1, NULL, "therad2");

	if(char_thread1)
	{
		printk("thread2 created successfully");
	}
	else
	{
		printk("thread2 created failed");
		 
	}
	
	return 0;
}

static void __exit my_therad_driver_exit(void)
{

	printk("exit driver\n");

	kthread_stop(char_thread);
	kthread_stop(char_thread1);
}
module_init(my_thread_driver_init);
module_exit(my_therad_driver_exit);


